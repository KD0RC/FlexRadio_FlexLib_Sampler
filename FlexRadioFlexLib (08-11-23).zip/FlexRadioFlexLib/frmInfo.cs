﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlexRadioFlexLib
{
    public partial class frmInfo : Form
    {
        public string SerNum;

        public frmInfo()
        {
            InitializeComponent();
        }

        private void lblSerial_MouseEnter(object sender, EventArgs e)
        {
            lblSerial.Text = SerNum;
        }

        private void lblSerialLabel_MouseEnter(object sender, EventArgs e)
        {
            lblSerial.Text = SerNum;
        }

        private void lblSerialLabel_MouseLeave(object sender, EventArgs e)
        {
            lblSerial.Text = SerNum.Substring(0, SerNum.Length - 4) + "****";
        }

        private void lblSerial_MouseLeave(object sender, EventArgs e)
        {
            lblSerial.Text = SerNum.Substring(0, SerNum.Length - 4) + "****";
        }

        private void frmInfo_Load(object sender, EventArgs e)
        {

        }
    }
}
