﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Flex.Smoothlake.FlexLib;

namespace FlexRadioFlexLib
{
    public partial class frmMain : Form
    {
        private Radio _thisRadio;
        private Slice _thisSlice;

        public string NL = Environment.NewLine;

        public frmMain()
        {
            InitializeComponent();

            API.RadioAdded += API_RadioAdded;
            API.RadioRemoved += API_RadioRemoved;
            //API.ProgramName = "K1PGV's test Program";
            API.ProgramName = "KD0RC test Program";
            API.Init();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void API_RadioAdded(Radio radio)
        {
            _thisRadio = radio;

            modelTextBox.Text = radio.Model;
            serialTextBox.Text += radio.Serial.Substring(0, radio.Serial.Length - 4) + "****";
            radioIPAddress.Text += radio.IP;

            // The properties, such as Nickname and Callsign, can't be read
            // successfully until you've received a PropertyChanged event
            // for that property... this is done after connect.
            //
            radio.PropertyChanged += radio_PropertyChanged;

            _thisRadio.Connect();
            txtDebug.Text = _thisRadio.TransmitSlice.ToString();
            //_thisSlice = radio.TransmitSlice;

            //radio.SliceAdded += new Radio.SliceAddedEventHandler(radio_SliceAdded);
            //_thisSlice.PropertyChanged += new PropertyChangedEventHandler(slice_PropertyChanged);
        }

        private void radio_SliceAdded(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("RF_Frequency"))
            {
                txtFreq.Text = _thisRadio.ActiveSlice.Freq.ToString();
            }
        }

        private void radio_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {


            if (e.PropertyName.Equals("Nickname"))
            {
                nickameTextBox.Text = _thisRadio.Nickname;
            }

            if (e.PropertyName.Equals("Callsign"))
            {
                callsignTextBox.Text = _thisRadio.Callsign;
            }

            if (e.PropertyName.Equals("GuiClients"))
            {
                txtStations.Text = _thisRadio.GuiClientStations.Replace(",", NL);
            }
            
            if (e.PropertyName.Contains("Versions"))
            {
                var n = _thisRadio.Versions.IndexOf("SmartSDR-mb=") + 13;
                var s = _thisRadio.Versions.IndexOf("#", n);
                txtVersion.Text = _thisRadio.Versions.Substring(n, s - n);
            }

            //txtDebug.Text += e.PropertyName.ToString() + NL;
            //Console.WriteLine($"{e.PropertyName.ToString() + NL}");
        }

        private void slice_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("RF_Frequency"))
            {
                txtFreq.Text = _thisRadio.ActiveSlice.Freq.ToString();
            }
        }

        private void API_RadioRemoved(Radio radio)
        {


        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            _thisRadio.Disconnect();
            Application.Exit();
        }

        private void serialTextBox_MouseEnter(object sender, EventArgs e)
        {
            serialTextBox.Text = _thisRadio.Serial;
        }

        private void serialTextBox_MouseLeave(object sender, EventArgs e)
        {
            serialTextBox.Text = _thisRadio.Serial.Substring(0, _thisRadio.Serial.Length - 4) + "****";
        }

        /*

private void button3_Click(object sender, EventArgs e)
{

   _thisRadio.Connect();
}

private void btnMute_Click(object sender, EventArgs e)
{
   // mute active slice audio
   _thisRadio.ActiveSlice.Mute = true;
   lblMute.Text = "Muted";
}


private void serialTextBox_TextChanged(object sender, EventArgs e)
{

}

private void radioIPAddress_TextChanged(object sender, EventArgs e)
{

}
*/
    }
}
