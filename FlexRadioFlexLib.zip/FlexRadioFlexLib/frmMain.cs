﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics; // to use Stopwatch feature
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using Flex.Smoothlake.FlexLib;

namespace FlexRadioFlexLib
{
    public partial class frmMain : Form
    {
        // Forms
        private Form1 form1 = new Form1();  // debug form
        private frmAbout frmAbout = new frmAbout();
        private frmInfo frmInfo = new frmInfo();

        // Flex Radio
        private Radio _thisRadio;
        private Slice slice0;
        private Slice slice1;
        private Spot OOBSpot = new Spot();
        private Spot MemSpot = new Spot();

        // Variables
        private int[,] BandData = new int[28, 10];

        private string Callsign;
        private int[] ClientHandle = new int[2];

        private bool DispDegF = true;

        private string[] License = { "EXTRA", "ADVANCED", "GENERAL", "TECH", "NOVICE" };
        private int LicenseIDX;

        private string MyLicense;

        private string Nickname;
        private string NL = Environment.NewLine;

        private bool OOBind = true;

        private float PATemp;

        private string SerNum;
        private bool SpeakFreq = false;
        private string[] Station = new string[2];

        private int TuneStep0;
        private int TuneStep1;

        private string Version;

        System.Speech.Synthesis.SpeechSynthesizer mainSpeechSynthesizer = new System.Speech.Synthesis.SpeechSynthesizer();
        Stopwatch TimeIt = new Stopwatch();
        Action beep = Console.Beep;

        public frmMain()
        {
            InitializeComponent();

            API.RadioAdded += API_RadioAdded;
            API.RadioRemoved += API_RadioRemoved;
            API.ProgramName = "KD0RC mini utility";
            API.Init();

            mainSpeechSynthesizer.SelectVoiceByHints(System.Speech.Synthesis.VoiceGender.Female);
            TimeIt.Start();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            outOfBandIndicatorToolStripMenuItem.Checked = OOBind;
        }

        private void API_RadioAdded(Radio radio)
        {
            _thisRadio = radio;

            SerNum = radio.Serial;

            // The properties, such as Nickname and Callsign, can't be read
            // successfully until you've received a PropertyChanged event
            // for that property... this is done after connect.
            //
            radio.PropertyChanged += radio_PropertyChanged;
            radio.SliceAdded += new Radio.SliceAddedEventHandler(radio_SliceAdded);
            radio.SliceRemoved += new Radio.SliceRemovedEventHandler(radio_SliceRemoved);
            radio.VoltsDataReady += new Radio.MeterDataReadyEventHandler(_thisRadio_VoltsDataReady);
            radio.PATempDataReady += new Radio.MeterDataReadyEventHandler(_thisRadio_PATempDataReady);
            radio.GUIClientAdded += new Radio.GUIClientAddedEventHandler(_thisRadio_GUIClientAdded);
            radio.GUIClientUpdated += new Radio.GUIClientUpdatedEventHandler(_thisRadio_GUIClientUpdated);
            radio.GUIClientRemoved += new Radio.GUIClientRemovedEventHandler(_thisRadio_GUIClientRemoved);

            radio.Connect();

            form1.txtDebug.Text += "Status: " + radio.Status + NL;
            form1.txtDebug.Text += _thisRadio.GuiClientHosts + NL;

            ParseConfig();
        }

        private void ParseConfig()
        {
            // Parse band data to provide out of band warning as a spot
            //string filename = @"C:\Users\lenko\Documents\TeensyMaestro\MMConfig\MMConfig.ini";
            //string filename = @"C:\deploy\KD0RC\Config.ini";
            string filename = @"Config.ini";
            var lines = File.ReadLines(filename);

            foreach (string line in lines)
            {
                //Console.WriteLine(line);
                int colon = line.IndexOf(':');
                if (colon > 0)
                {
                    string parm = line.Substring(0, colon).Trim();
                    int sp;

                    switch (parm.ToUpper())
                    {
                        case "MYLICENSE":
                            sp = line.IndexOf(' ', colon + 2);
                            MyLicense = line.Substring(colon + 1, sp - colon).Trim();
                            Console.WriteLine(MyLicense);
                            if (MyLicense != "")
                            {
                                for (int i = 0; i < 5; i++)
                                {
                                    if (MyLicense.ToUpper() == License[i].ToUpper())
                                    {
                                        LicenseIDX = i;
                                        break;
                                    }
                                }
                            }
                            break;

                        case "SPOT":
                            sp = line.IndexOf(' ', colon + 2);
                            string SpotFreq = line.Substring(colon + 1, sp - colon).Trim();

                            sp = line.IndexOf(' ', sp);
                            string SpotText = line.Substring(sp).Trim();

                            MemSpot.Callsign = SpotText;
                            MemSpot.RXFrequency = Convert.ToDouble(SpotFreq);
                            _thisRadio.RequestSpot(MemSpot);

                            break;

                        case "160 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(0, line, colon);
                            break;

                        case "160 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(1, line, colon);
                            break;

                        case "80 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(2, line, colon);
                            break;

                        case "80 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(3, line, colon);
                            break;

                        case "40 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(4, line, colon);
                            break;

                        case "40 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(5, line, colon);
                            break;

                        case "30 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(6, line, colon);
                            break;

                        case "30 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(7, line, colon);
                            break;

                        case "20 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(8, line, colon);
                            break;

                        case "20 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(9, line, colon);
                            break;

                        case "17 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(10, line, colon);
                            break;

                        case "17 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(11, line, colon);
                            break;

                        case "15 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(12, line, colon);
                            break;

                        case "15 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(13, line, colon);
                            break;

                        case "12 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(14, line, colon);
                            break;

                        case "12 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(15, line, colon);
                            break;

                        case "10 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(16, line, colon);
                            break;

                        case "10 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(17, line, colon);
                            break;

                        case "6 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(18, line, colon);
                            break;

                        case "6 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(19, line, colon);
                            break;

                        case "2 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(20, line, colon);
                            break;

                        case "2 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(21, line, colon);
                            break;

                        case "1.25 CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(22, line, colon);
                            break;

                        case "1.25 PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(23, line, colon);
                            break;

                        case "70CM CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(24, line, colon);
                            break;

                        case "70CM PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(25, line, colon);
                            break;

                        case "33CM CW":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(26, line, colon);
                            break;

                        case "33CM PHONE":
                            //Console.WriteLine(parm);
                            _ = ParseBandData(27, line, colon);
                            break;

                        default:
                            break;
                    }
                }
            }
        }

        private void _thisRadio_GUIClientRemoved(GUIClient client)
        {
            //lstStations.Items.RemoveAt(1)
            if(client.ClientHandle == ClientHandle[0])
            {
                if (lstStations.Items.Count > 0)
                {
                    lstStations.Items.RemoveAt(0);
                }
            }

            if (client.ClientHandle == ClientHandle[1])
            {
                if(lstStations.Items.Count > 1)
                {
                    lstStations.Items.RemoveAt(1);
                }
                
            }

            form1.txtDebug.Text += "GUI Client Removed: " + client.Station + "    " + client.ClientHandle + NL;
        }

        private void _thisRadio_GUIClientUpdated(GUIClient client)
        {
            form1.txtDebug.Text += "GUI Client Updated: " + client.Station + "    " + client.ClientHandle + NL;
            //txtDebug.Text += client.ClientHandle + NL;

            if (client.ClientHandle != ClientHandle[0] && client.ClientHandle != ClientHandle[1])
            {
                if(ClientHandle[0] == 0)
                {
                    ClientHandle[0] = Convert.ToInt32(client.ClientHandle);
                    Station[0] = client.Station;
                    if(Station[0] != null)
                    {
                        lstStations.Items.Add(Station[0]);
                        lstStations.SelectedIndex = 0;
                        string ClientID = _thisRadio.FindGUIClientByClientHandle((uint)ClientHandle[0]).ClientID.ToString();
                        _thisRadio.BindGUIClient(ClientID);
                    }
                    else
                    {
                        lstStations.Items.Remove(0);
                    }
                }
                else if (ClientHandle[1] == 0)
                {
                    ClientHandle[1] = Convert.ToInt32(client.ClientHandle);
                    Station[1] = client.Station;
                    if(Station[1] != null)
                    {
                        lstStations.Items.Add(Station[1]);
                    }
                    else 
                    {
                        lstStations.Items.Remove(1);
                    }
                }
            }


            form1.txtDebug.Text += "Station[0] " + Station[0] + "  ClientHandle[0] " + ClientHandle[0] + NL;
            form1.txtDebug.Text += "Station[1] " + Station[1] + "  ClientHandle[1] " + ClientHandle[1] + NL;

            if (slice0 != null)
            {
                if (slice0.ClientHandle.Equals(client.ClientHandle))
                {
                    lblSlice0.Text = "Slice " + slice0.Letter + "    " + client.Station;
                }
            }

            if (slice1 != null)
            {
                if (slice1.ClientHandle.Equals(client.ClientHandle))
                {
                    lblSlice1.Text = "Slice " + slice1.Letter + "    " + client.Station;
                }
            }

        }

        private void _thisRadio_GUIClientAdded(GUIClient client)
        {
            //form1.txtDebug.Text += "GUI Client Added: " + client.Station + NL;

            form1.txtDebug.Text += "GUI Client Added: " + client.Station + "    " + client.ClientHandle + NL;
            //txtDebug.Text += client.ClientHandle + NL;

            if (client.ClientHandle != ClientHandle[0] && client.ClientHandle != ClientHandle[1])
            {
                if (ClientHandle[0] == 0)
                {
                    ClientHandle[0] = Convert.ToInt32(client.ClientHandle);
                    Station[0] = client.Station;
                    if (Station[0] != null)
                    {
                        lstStations.Items.Add(Station[0]);
                        //lstStations.SelectedIndex = 0;
                        //string ClientID = _thisRadio.FindGUIClientByClientHandle((uint)ClientHandle[0]).ClientID.ToString();
                        //_thisRadio.BindGUIClient(ClientID);
                    }
                    //else
                    //{
                    //    lstStations.Items.Remove(0);
                    //}
                }
                else if (ClientHandle[1] == 0)
                {
                    ClientHandle[1] = Convert.ToInt32(client.ClientHandle);
                    Station[1] = client.Station;
                    if (Station[1] != null)
                    {
                        lstStations.Items.Add(Station[1]);
                    }
                    //else
                    //{
                    //    lstStations.Items.Remove(1);
                    //}
                }
            }


            form1.txtDebug.Text += "Station[0] " + Station[0] + "  ClientHandle[0] " + ClientHandle[0] + NL;
            form1.txtDebug.Text += "Station[1] " + Station[1] + "  ClientHandle[1] " + ClientHandle[1] + NL;

            if (slice0 != null)
            {
                if (slice0.ClientHandle.Equals(client.ClientHandle))
                {
                    lblSlice0.Text = "Slice " + slice0.Letter + "    " + client.Station;
                }
            }

            if (slice1 != null)
            {
                if (slice1.ClientHandle.Equals(client.ClientHandle))
                {
                    lblSlice1.Text = "Slice " + slice1.Letter + "    " + client.Station;
                }
            }
        }

        private void _thisRadio_PATempDataReady(float data)
        {
            //(°F) = (Celsius x 1.8) +32
            if(DispDegF)
            {
                PATemp = data;
                lblTemp.Text = String.Format("{0, 0:.00° F}", (data * 1.8f) + 32);
            }
            else
            {
                lblTemp.Text = String.Format("{0, 0:.00° C}", data);
            }
            
            //txtDebug.Text += data.ToString() + NL;
        }

        private void _thisRadio_VoltsDataReady(float data)
        {
            lblVolts.Text = String.Format("{0, 0:.00 V}", data);
            //txtDebug.Text = data.ToString();
        }

        private void radio_SliceAdded(Slice slice)
        {
            //txtDebug.Text = "Slice: " + slice.Index.ToString() + "    " + slice.ClientHandle.ToString() + NL;
            
            if (slice.Index == 0)
            {
                slice0 = slice;
                slice0.PropertyChanged += new PropertyChangedEventHandler(slice0_PropertyChanged);
                //txtDebug.Text += slice0.ClientHandle.ToString() + NL;

                lblSlice0.Text = "Slice " + slice0.Letter + "    ";

                txtFreq0.Text = slice0.Freq.ToString("0.000 000");
                txtFreq0.BackColor = Color.White;

                if (SpeakFreq)
                {
                    mainSpeechSynthesizer.SpeakAsync("SLICE:  A:  " + txtFreq0.Text);
                }

                CheckOOB(0, slice0.Freq, slice0.DemodMode, slice0.IsTransmitSlice);

                if (slice0.Mute)
                {
                    btnMute0.Text = "Un-Mute";
                }
                else if (!slice0.Mute)
                {
                    btnMute0.Text = "Mute";
                }

                for (int i = 0; i < slice0.ModeList.Count; i++)
                {
                    cmbMode0.Items.Add(slice0.ModeList.ElementAt(i));
                    
                    if (slice0.ModeList.ElementAt(i) == slice0.DemodMode)
                    {
                        cmbMode0.SelectedIndex = i;
                    }
                    //form1.txtDebug.Text += slice0.ModeList.Count.ToString() + "  " + slice0.ModeList.ElementAt(i) + NL;
                }

                form1.txtDebug.Text += "Added slice0:" + slice0.ClientHandle.ToString() + NL;

                for (int i = 0; i < 2; i++)
                {
                    if (slice0.ClientHandle == ClientHandle[i])
                    {
                        lblSlice0.Text += Station[i];
                    }
                }

                TuneStep0 = slice0.TuneStep;
                trkVol0.Value = slice0.AudioGain;
            }
            else if (slice.Index == 1)
            {
                slice1 = slice;
                slice1.PropertyChanged += new PropertyChangedEventHandler(slice1_PropertyChanged);

                lblSlice1.Text = "Slice " + slice1.Letter + "    ";

                txtFreq1.Text = slice1.Freq.ToString("0.000 000");
                txtFreq1.BackColor = Color.White;

                if (SpeakFreq)
                {
                    mainSpeechSynthesizer.SpeakAsync("SLICE:  B:  " + txtFreq1.Text);
                }

                CheckOOB(1, slice1.Freq, slice1.DemodMode, slice1.IsTransmitSlice);

                if (slice1.Mute)
                {
                    btnMute1.Text = "Un-Mute";
                }
                else if (!slice1.Mute)
                {
                    btnMute1.Text = "Mute";
                }

                for (int i = 0; i < slice1.ModeList.Count; i++)
                {
                    cmbMode1.Items.Add(slice1.ModeList.ElementAt(i));
                    if (slice1.ModeList.ElementAt(i) == slice1.DemodMode)
                    {
                        cmbMode1.SelectedIndex = i;
                    }
                    //form1.txtDebug.Text += slice1.ModeList.Count.ToString() + "  " + slice1.ModeList.ElementAt(i) + NL;
                }

                form1.txtDebug.Text += "Added slice1:" + slice1.ClientHandle.ToString() + NL;

                for (int i = 0; i < 2; i++)
                {
                    if (slice1.ClientHandle == ClientHandle[i])
                    {
                        lblSlice1.Text += Station[i];
                    }
                }

                TuneStep1 = slice1.TuneStep;
                trkVol1.Value = slice1.AudioGain;
            }

            //form1.txtDebug.Text += "Slice: " + slice.ToString();
            //form1.txtDebug.Text += "     GUI Client Handle: " + slice.ClientHandle + NL;
            //form1.txtDebug.Text += GUIClient + NL + NL;

            if (slice0 != null && slice1 != null)
            {
                btnAtoB.Text = slice0.Letter + ">" + slice1.Letter;
                btnBtoA.Text = slice0.Letter + "<" + slice1.Letter;
                btnAtoB.Visible = true;
                btnBtoA.Visible = true;
            }
            else
            {
                btnAtoB.Visible = false;
                btnBtoA.Visible = false;
            }

            btnMute0.Visible = slice0 != null;
            btnMute1.Visible = slice1 != null;
            txtFreq0.Visible = slice0 != null;
            txtFreq1.Visible = slice1 != null;
            btnFreq0Up.Visible = slice0 != null;
            btnFreq1Up.Visible = slice1 != null;
            btnFreq0Dn.Visible = slice0 != null;
            btnFreq1Dn.Visible = slice1 != null;
            cmbMode0.Visible = slice0 != null;
            cmbMode1.Visible = slice1 != null;
            picVol0.Visible = slice0 != null;
            picVol1.Visible = slice1 != null;
            trkVol0.Visible = slice0 != null;
            trkVol1.Visible = slice1 != null;
        }

        private void radio_SliceRemoved(Slice slice)
        {
            if (slice.Index == 0)
            {
                lblSlice0.Text = "";
                txtFreq0.Text = "";
                slice0 = null;
                btnAtoB.Visible = false;
                btnBtoA.Visible = false;

                cmbMode0.Items.Clear();

                mainSpeechSynthesizer.SpeakAsyncCancelAll();

                if (SpeakFreq)
                {
                    mainSpeechSynthesizer.SpeakAsync("SLICE:  A:  CLOSED");
                }
            }
            else if (slice.Index == 1)
            {
                lblSlice1.Text = "";
                txtFreq1.Text = "";
                slice1 = null;
                btnAtoB.Visible = false;
                btnBtoA.Visible = false;

                cmbMode1.Items.Clear();

                mainSpeechSynthesizer.SpeakAsyncCancelAll();

                if (SpeakFreq)
                {
                    mainSpeechSynthesizer.SpeakAsync("SLICE:  B:  CLOSED");
                }
            }

            btnMute0.Visible = slice0 != null;
            btnMute1.Visible = slice1 != null;
            txtFreq0.Visible = slice0 != null;
            txtFreq1.Visible = slice1 != null;
            btnFreq0Up.Visible = slice0 != null;
            btnFreq1Up.Visible = slice1 != null;
            btnFreq0Dn.Visible = slice0 != null;
            btnFreq1Dn.Visible = slice1 != null;
            cmbMode0.Visible = slice0 != null;
            cmbMode1.Visible = slice1 != null;
            picVol0.Visible = slice0 != null;
            picVol1.Visible = slice1 != null;
            trkVol0.Visible = slice0 != null;
            trkVol1.Visible = slice1 != null;
        }

        private void radio_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("Nickname"))
            {
                Nickname = _thisRadio.Nickname;
            }

            if (e.PropertyName.Equals("Callsign"))
            {
                this.Text = "FlexRadio - " + _thisRadio.Callsign + " - " + MyLicense + " Class";
                Callsign = _thisRadio.Callsign;
            }

            if (e.PropertyName.Equals("RFPower"))
            {
                lblRFPower.Text = _thisRadio.RFPower.ToString();
            }

            if (e.PropertyName.Equals("TunePower"))
            {
                lblTunePower.Text = _thisRadio.TunePower.ToString();
            }

            if (e.PropertyName.Equals("CWSpeed"))
            {
                txtCWSpeed.Text = _thisRadio.CWSpeed.ToString();
                txtCWSpeed.BackColor = Color.White;
            }

            if (e.PropertyName.Contains("Versions"))
            {
                int n = _thisRadio.Versions.IndexOf("SmartSDR-mb=") + 13;
                int s = _thisRadio.Versions.IndexOf("#", n);
                Version = _thisRadio.Versions.Substring(n, s - n);
            }

            //form1.txtDebug.Text += e.PropertyName.ToString() + NL;
            //Console.WriteLine($"{e.PropertyName + NL}");
        }

        private void slice0_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CheckOOB(0, slice0.Freq, slice0.DemodMode, slice0.IsTransmitSlice);

            if (e.PropertyName.Equals("Freq"))
            {
                txtFreq0.Text = slice0.Freq.ToString("0.000 000");
                txtFreq0.BackColor = Color.White;

                
                mainSpeechSynthesizer.SpeakAsyncCancelAll();

                if (SpeakFreq)
                {
                    beep.BeginInvoke((a) => { beep.EndInvoke(a); }, null);
                    form1.txtDebug.Text += TimeIt.ElapsedMilliseconds + NL;
                    if (TimeIt.ElapsedMilliseconds > 200)
                    {
                        if (SpeakFreq)
                        {
                            mainSpeechSynthesizer.SpeakAsync("SLICE:  A:  " + txtFreq0.Text);
                        }

                        TimeIt.Reset();
                        TimeIt.Start();
                    }
                }
            }

            if (e.PropertyName.Equals("Mute"))
            {
                if(slice0 == null)
                {
                    return;
                }

                if (slice0.Mute)
                {
                    btnMute0.Text = "Un-Mute";
                }
                else if (!slice0.Mute)
                {
                    btnMute0.Text = "Mute";
                }

            }

            if (e.PropertyName.Equals("TuneStep"))
            {
                TuneStep0 = slice0.TuneStep;
            }

            //DemodMode
            if (e.PropertyName.Equals("DemodMode"))
            {
                for (int i = 0; i < slice0.ModeList.Count; i++)
                {
                    if (slice0.ModeList.ElementAt(i) == slice0.DemodMode)
                    {
                        cmbMode0.SelectedIndex = i;
                    }
                    form1.txtDebug.Text += slice0.ModeList.Count.ToString() + "  " + slice0.ModeList.ElementAt(i) + NL;
                }
            }

            if (e.PropertyName.Equals("AudioGain"))
            {
                trkVol0.Value = slice0.AudioGain;
            }

            //Console.WriteLine($"{e.PropertyName.ToString() + NL}");
            //form1.txtDebug.Text += e.PropertyName.ToString() + NL;
            //form1.txtDebug.Text += "slice0:" + slice0.ClientHandle.ToString() + NL;
            //form1.txtDebug.Text += "slice1:" + slice0.ClientHandle.ToString() + NL;
        }

        private void slice1_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CheckOOB(1, slice1.Freq, slice1.DemodMode, slice1.IsTransmitSlice);
            if (e.PropertyName.Equals("Freq"))
            {
                txtFreq1.Text = slice1.Freq.ToString("0.000 000");
                txtFreq1.BackColor = Color.White;

                
                mainSpeechSynthesizer.SpeakAsyncCancelAll();

                if (SpeakFreq)
                {
                    beep.BeginInvoke((a) => { beep.EndInvoke(a); }, null);
                    form1.txtDebug.Text += TimeIt.ElapsedMilliseconds + NL;
                    if (TimeIt.ElapsedMilliseconds > 200)
                    {
                        mainSpeechSynthesizer.SpeakAsync("SLICE:  B:  " + txtFreq1.Text);
                        TimeIt.Reset();
                        TimeIt.Start();
                    }
                }
 

            }

            if (e.PropertyName.Equals("Mute"))
            {
                if (slice1 == null)
                {
                    return;
                }

                if (slice1.Mute)
                {
                    btnMute1.Text = "Un-Mute";
                }
                else
                {
                    btnMute1.Text = "Mute";
                }
            }

            if (e.PropertyName.Equals("TuneStep"))
            {
                TuneStep1 = slice1.TuneStep;
            }

            if (e.PropertyName.Equals("DemodMode"))
            {
                for (int i = 0; i < slice1.ModeList.Count; i++)
                {
                    if (slice1.ModeList.ElementAt(i) == slice1.DemodMode)
                    {
                        cmbMode1.SelectedIndex = i;
                    }
                    form1.txtDebug.Text += slice1.ModeList.Count.ToString() + "  " + slice1.ModeList.ElementAt(i) + NL;
                }
            }

            if (e.PropertyName.Equals("AudioGain"))
            {
                trkVol1.Value = slice1.AudioGain;
            }

            //form1.txtDebug.Text += "slice0:" + slice0.ClientHandle.ToString() + NL;
            //form1.txtDebug.Text += "slice1:" + slice0.ClientHandle.ToString() + NL;
        }

        private void API_RadioRemoved(Radio radio)
        {


        }

        private void btnMute0_Click(object sender, EventArgs e)
        {
            if (slice0 == null)
            {
                return;
            }

            if (slice0.Mute)
            {
                btnMute0.Text = "Mute";
                slice0.Mute = false;
            }
            else
            {
                btnMute0.Text = "Un-Mute";
                slice0.Mute = true;
            }
            
        }

        private void btnMute1_Click(object sender, EventArgs e)
        {
            if(slice1 == null)
            {
                return;
            }

            if (slice1.Mute)
            {
                btnMute1.Text = "Mute";
                slice1.Mute = false;
            }
            else
            {
                btnMute1.Text = "Un-Mute";
                slice1.Mute = true;
            }
        }

        private void btnAtoB_Click(object sender, EventArgs e)
        {
            if (slice0 != null && slice1 != null)
            {
                slice1.Freq = slice0.Freq;
            }
        }

        private void btnBtoA_Click(object sender, EventArgs e)
        {
            if (slice0 != null && slice1 != null)
            {
                slice0.Freq = slice1.Freq;
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //mainSpeechSynthesizer.SpeakAsyncCancelAll();
            //mainSpeechSynthesizer.SetOutputToNull();
            

            if (_thisRadio != null)
            {
                _thisRadio.Disconnect();
                //Console.WriteLine($"Gracefully Disconnected     **************************************");

            }
        }

        private void lblTemp_Click(object sender, EventArgs e)
        {
            DispDegF = !DispDegF;

            if (DispDegF)
            {
                lblTemp.Text = String.Format("{0, 0:.00° F}", (PATemp * 1.8f) + 32);
            }
            else
            {
                lblTemp.Text = String.Format("{0, 0:.00° C}", PATemp);
            }
        }

        private void lblDebug_Click(object sender, EventArgs e)
        {
            //Form1 form1 = new Form1();
            //form1.lblDebug.Text += txtFreq0.Text;
            //form1.Show();
            form1.ShowDialog();
        }

        private void lblDebug_MouseEnter(object sender, EventArgs e)
        {
            lblDebug.BackColor = Color.Red;
        }

        private void lblDebug_MouseLeave(object sender, EventArgs e)
        {
            lblDebug.BackColor = frmMain.DefaultBackColor;
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void radioInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(_thisRadio == null)
            {
                return;
            }
            if(frmInfo.IsDisposed)
            {
                frmInfo = new frmInfo();
            }

            frmInfo.SerNum = SerNum;
            frmInfo.lblSerial.Text = _thisRadio.Serial.Substring(0, _thisRadio.Serial.Length - 4) + "****";
            frmInfo.lblModel.Text = _thisRadio.Model;
            frmInfo.lblIPAddr.Text = _thisRadio.IP.ToString();
            frmInfo.lblNickname.Text = Nickname;
            frmInfo.lblCallsign.Text = Callsign;
            frmInfo.lblVersion.Text = Version;

            frmInfo.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout.ShowDialog();
        }

        private void txtFreq0_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            double Freq = 0;
            if(ConvertFreqToDouble(txtFreq0.Text, ref Freq))
            {
                slice0.Freq = Freq;
                txtFreq0.BackColor = Color.White;
            }
            else
            {
                txtFreq0.BackColor = Color.Red;
            }
        }

        private void txtFreq0_KeyPress(object sender, KeyPressEventArgs e)
        {
            double Freq = 0;
            if(ConvertFreqToDouble(txtFreq0.Text, ref Freq))
            {
                if (e.KeyChar == '\r')
                {
                    slice0.Freq = Freq;
                    txtFreq0.BackColor = Color.White;
                }
            }
            else
            {
                txtFreq0.BackColor = Color.Red; // illegal chars typed in
            }
        }

        private void txtFreq1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            double Freq = 0;
            if(ConvertFreqToDouble(txtFreq1.Text, ref Freq))
            {
                slice1.Freq = Freq;
                txtFreq1.BackColor = Color.White;
            }
            else
            {
                txtFreq1.BackColor = Color.Red;
            }
        }

        private void txtFreq1_KeyPress(object sender, KeyPressEventArgs e)
        {
            double Freq = 0;
            if(ConvertFreqToDouble(txtFreq1.Text, ref Freq))
            {
                if (e.KeyChar == '\r')
                {
                    slice1.Freq = Freq;
                    txtFreq1.BackColor = Color.White;
                }
            }
            else
            {
                txtFreq0.ForeColor = Color.Black;
                txtFreq1.BackColor = Color.Red;
            }
        }

        private bool ConvertFreqToDouble(string txtFreq, ref double dblFreq)
        {
            string tmpStr;

            int n = txtFreq.IndexOf(' ');
            if (n > 0)
            {
                tmpStr = txtFreq.Substring(0, n) + txtFreq.Substring(n + 1);
            }
            else
            {
                tmpStr = txtFreq;
            }

            if (double.TryParse(tmpStr, out dblFreq))
            {
                dblFreq = Convert.ToDouble(tmpStr);
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool ParseBandData(int Band, string line, int colon)
        {
            bool GoodNum;
            int frqIDX = colon + 1;
            int comma = line.IndexOf(',', colon);


            for (int i = 0; i < 9; i++)
            {
                GoodNum = Int32.TryParse(line.Substring(frqIDX, comma - frqIDX).Trim(), out BandData[Band, i]);
                Console.WriteLine(BandData[Band, i]);
                frqIDX = comma + 1;
                comma = line.IndexOf(',', frqIDX);
            }

            GoodNum = Int32.TryParse(line.Substring(frqIDX).Trim(), out BandData[Band, 9]);
            Console.WriteLine(BandData[Band, 9]);

            return GoodNum;
        }

        private void CheckOOB(int slice, double Frq, string Mde, bool IsTX)
        {
            bool OOB = true;

            if(!OOBind)
            {
                txtFreq0.ForeColor = Color.Black;
                txtFreq1.ForeColor = Color.Black;

                return;
            }

            if (MyLicense != "")
            {
                if(!IsTX)
                {
                    if(slice == 0)
                    {
                        txtFreq0.ForeColor = Color.Black;
                    }
                    else
                    {
                        txtFreq1.ForeColor = Color.Black;
                    }
 
                    return;
                }

                int strt;
                if(Mde.ToUpper() == "CW" || Mde.ToUpper() == "DIGU" || Mde.ToUpper() == "DIGL" || Mde.ToUpper() == "RTTY")
                {
                    strt = 0;
                }
                else
                {
                    strt = 1;
                }

                for (int i=strt; i<28; i+=2)
                {
                    if ((Frq > (double)BandData[i, LicenseIDX * 2] / 1000000) && (Frq < (double)BandData[i, (LicenseIDX * 2) + 1] / 1000000))
                    {
                        if (slice == 0)
                        {
                            txtFreq0.ForeColor = Color.Black;
                        }
                        else
                        {
                            txtFreq1.ForeColor = Color.Black;
                        }

                        OOB = false;
                        break;
                    }
                }

                if(OOB)
                {
                    if (slice == 0)
                    {
                        txtFreq0.ForeColor = Color.Red;
                    }
                    else
                    {
                        txtFreq1.ForeColor = Color.Red;
                    }

                    OOBSpot.Callsign = "**Out_Of_Band**";
                    OOBSpot.LifetimeSeconds = 5;
                    OOBSpot.Color = "White";
                    OOBSpot.RXFrequency = Frq;
                    _thisRadio.RequestSpot(OOBSpot);
                    Console.WriteLine(Frq);
                }

            }
        }

        private void btnFreq0Up_Click(object sender, EventArgs e)
        {
            double Freq = 0;

            if(ConvertFreqToDouble(txtFreq0.Text, ref Freq))
            {
                Freq *= 1_000_000;

                Freq += TuneStep0;
                slice0.Freq = Freq / 1_000_000;
                Freq = 0;
                txtFreq0.BackColor = Color.White;
            }
            else
            {
                txtFreq0.BackColor = Color.Red;
            }
        }

        private void btnFreq0Dn_Click(object sender, EventArgs e)
        {
            double Freq = 0;

            if(ConvertFreqToDouble(txtFreq0.Text, ref Freq))
            {
                Freq *= 1_000_000;

                Freq -= TuneStep0;
                slice0.Freq = Freq / 1_000_000;
                Freq = 0;
                txtFreq0.BackColor = Color.White;
            }
            else
            {
                txtFreq0.BackColor = Color.Red;
            }
        }

        private void btnFreq1Up_Click(object sender, EventArgs e)
        {
            double Freq = 0;

            if(ConvertFreqToDouble(txtFreq1.Text, ref Freq))
            {
                Freq *= 1_000_000;

                Freq += TuneStep1;
                slice1.Freq = Freq / 1_000_000;
                Freq = 0;
                txtFreq1.BackColor = Color.White;
            }
            else
            {
                txtFreq1.BackColor = Color.Red;
            }
        }

        private void btnFreq1Dn_Click(object sender, EventArgs e)
        {
            double Freq = 0;

            if(ConvertFreqToDouble(txtFreq1.Text, ref Freq))
            {
                Freq *= 1_000_000;

                Freq -= TuneStep1;
                slice1.Freq = Freq / 1_000_000;
                Freq = 0;
                txtFreq1.BackColor = Color.White;
            }
            else
            {
                txtFreq1.BackColor = Color.Red;
            }
        }

        private void showDebugScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form1.ShowDialog();
        }

        private void cmbMode0_SelectedIndexChanged(object sender, EventArgs e)
        {
            slice0.DemodMode = cmbMode0.SelectedItem.ToString();
        }

        private void cmbMode1_SelectedIndexChanged(object sender, EventArgs e)
        {
            slice1.DemodMode = cmbMode1.SelectedItem.ToString();
        }

        private void lstStations_DoubleClick(object sender, EventArgs e)
        {
            string ClientID = _thisRadio.FindGUIClientByClientHandle((uint)ClientHandle[lstStations.SelectedIndex]).ClientID.ToString();
            _thisRadio.BindGUIClient(ClientID);
            form1.txtDebug.Text += ClientHandle[lstStations.SelectedIndex].ToString() + NL;
            form1.txtDebug.Text += _thisRadio.BoundClientID + NL;
            form1.txtDebug.Text += ClientID + NL;
        }

        private void txtCWSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                if (int.TryParse(txtCWSpeed.Text, out int Speed))
                {
                    _thisRadio.CWSpeed = Speed;
                    txtCWSpeed.BackColor = Color.White;
                }
                else
                {
                    txtCWSpeed.BackColor = Color.Red;
                }
            }
        }

        private void trkVol0_Scroll(object sender, EventArgs e)
        {
            slice0.AudioGain = trkVol0.Value;
        }

        private void trkVol1_Scroll(object sender, EventArgs e)
        {
            slice1.AudioGain = trkVol1.Value;
        }

        private void outOfBandIndicatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OOBind = !OOBind;
            outOfBandIndicatorToolStripMenuItem.Checked = OOBind;
            if(OOBind)
            {
                if(slice0 != null)
                {
                    CheckOOB(0, slice0.Freq, slice0.DemodMode, slice0.IsTransmitSlice);
                }

                if (slice1 != null)
                {
                    CheckOOB(1, slice0.Freq, slice1.DemodMode, slice1.IsTransmitSlice);
                }   
            }
            else
            {
                txtFreq0.ForeColor = Color.Black;
                txtFreq1.ForeColor = Color.Black;
            }
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            mainSpeechSynthesizer.SpeakAsyncCancelAll();
            mainSpeechSynthesizer.SpeakAsyncCancelAll();
        }

        private void txtFreq0_Click(object sender, EventArgs e)
        {
            if (SpeakFreq)
            {
                mainSpeechSynthesizer.SpeakAsync("SLICE:  A:  " + txtFreq0.Text);
            }
        }

        private void txtFreq1_Click(object sender, EventArgs e)
        {
            if(SpeakFreq)
            {
                mainSpeechSynthesizer.SpeakAsync("SLICE:  B:  " + txtFreq1.Text);
            }
        }

        private void speakFrequencyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpeakFreq = !SpeakFreq;
            speakFrequencyToolStripMenuItem.Checked = SpeakFreq;
        }
    }
}
