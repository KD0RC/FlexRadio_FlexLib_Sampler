﻿
namespace FlexRadioFlexLib
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.txtFreq0 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnMute0 = new System.Windows.Forms.Button();
            this.btnMute1 = new System.Windows.Forms.Button();
            this.txtFreq1 = new System.Windows.Forms.TextBox();
            this.lblSlice0 = new System.Windows.Forms.Label();
            this.lblSlice1 = new System.Windows.Forms.Label();
            this.btnAtoB = new System.Windows.Forms.Button();
            this.btnBtoA = new System.Windows.Forms.Button();
            this.lblVolts = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTemp = new System.Windows.Forms.Label();
            this.lblDebug = new System.Windows.Forms.Label();
            this.lstStations = new System.Windows.Forms.ListBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outOfBandIndicatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showDebugScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radioInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnFreq0Up = new System.Windows.Forms.Button();
            this.btnFreq0Dn = new System.Windows.Forms.Button();
            this.btnFreq1Dn = new System.Windows.Forms.Button();
            this.btnFreq1Up = new System.Windows.Forms.Button();
            this.cmbMode0 = new System.Windows.Forms.ComboBox();
            this.cmbMode1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRFPower = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTunePower = new System.Windows.Forms.Label();
            this.txtCWSpeed = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.trkVol0 = new System.Windows.Forms.TrackBar();
            this.trkVol1 = new System.Windows.Forms.TrackBar();
            this.picVol0 = new System.Windows.Forms.PictureBox();
            this.picVol1 = new System.Windows.Forms.PictureBox();
            this.speakFrequencyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkVol0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkVol1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVol0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVol1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtFreq0
            // 
            this.txtFreq0.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFreq0.Location = new System.Drawing.Point(106, 50);
            this.txtFreq0.Name = "txtFreq0";
            this.txtFreq0.Size = new System.Drawing.Size(263, 45);
            this.txtFreq0.TabIndex = 5;
            this.txtFreq0.Click += new System.EventHandler(this.txtFreq0_Click);
            this.txtFreq0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreq0_KeyPress);
            this.txtFreq0.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtFreq0_MouseDoubleClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 345);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 40);
            this.label6.TabIndex = 14;
            this.label6.Text = "Stations Connected:\r\n(double-click to select)";
            // 
            // btnMute0
            // 
            this.btnMute0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMute0.Location = new System.Drawing.Point(8, 50);
            this.btnMute0.Name = "btnMute0";
            this.btnMute0.Size = new System.Drawing.Size(92, 45);
            this.btnMute0.TabIndex = 17;
            this.btnMute0.Text = "Mute";
            this.btnMute0.UseVisualStyleBackColor = true;
            this.btnMute0.Click += new System.EventHandler(this.btnMute0_Click);
            // 
            // btnMute1
            // 
            this.btnMute1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMute1.Location = new System.Drawing.Point(525, 50);
            this.btnMute1.Name = "btnMute1";
            this.btnMute1.Size = new System.Drawing.Size(92, 45);
            this.btnMute1.TabIndex = 19;
            this.btnMute1.Text = "Mute";
            this.btnMute1.UseVisualStyleBackColor = true;
            this.btnMute1.Click += new System.EventHandler(this.btnMute1_Click);
            // 
            // txtFreq1
            // 
            this.txtFreq1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFreq1.Location = new System.Drawing.Point(623, 50);
            this.txtFreq1.Name = "txtFreq1";
            this.txtFreq1.Size = new System.Drawing.Size(263, 45);
            this.txtFreq1.TabIndex = 18;
            this.txtFreq1.Click += new System.EventHandler(this.txtFreq1_Click);
            this.txtFreq1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreq1_KeyPress);
            this.txtFreq1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtFreq1_MouseDoubleClick);
            // 
            // lblSlice0
            // 
            this.lblSlice0.AutoSize = true;
            this.lblSlice0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlice0.Location = new System.Drawing.Point(105, 27);
            this.lblSlice0.Name = "lblSlice0";
            this.lblSlice0.Size = new System.Drawing.Size(0, 20);
            this.lblSlice0.TabIndex = 20;
            // 
            // lblSlice1
            // 
            this.lblSlice1.AutoSize = true;
            this.lblSlice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlice1.Location = new System.Drawing.Point(619, 27);
            this.lblSlice1.Name = "lblSlice1";
            this.lblSlice1.Size = new System.Drawing.Size(0, 20);
            this.lblSlice1.TabIndex = 21;
            // 
            // btnAtoB
            // 
            this.btnAtoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtoB.Location = new System.Drawing.Point(435, 38);
            this.btnAtoB.Name = "btnAtoB";
            this.btnAtoB.Size = new System.Drawing.Size(56, 27);
            this.btnAtoB.TabIndex = 22;
            this.btnAtoB.Text = "A>B";
            this.btnAtoB.UseVisualStyleBackColor = true;
            this.btnAtoB.Click += new System.EventHandler(this.btnAtoB_Click);
            // 
            // btnBtoA
            // 
            this.btnBtoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBtoA.Location = new System.Drawing.Point(435, 71);
            this.btnBtoA.Name = "btnBtoA";
            this.btnBtoA.Size = new System.Drawing.Size(56, 27);
            this.btnBtoA.TabIndex = 23;
            this.btnBtoA.Text = "A<B";
            this.btnBtoA.UseVisualStyleBackColor = true;
            this.btnBtoA.Click += new System.EventHandler(this.btnBtoA_Click);
            // 
            // lblVolts
            // 
            this.lblVolts.AutoSize = true;
            this.lblVolts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVolts.Location = new System.Drawing.Point(84, 401);
            this.lblVolts.Name = "lblVolts";
            this.lblVolts.Size = new System.Drawing.Size(21, 20);
            this.lblVolts.TabIndex = 24;
            this.lblVolts.Text = "V";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 20);
            this.label8.TabIndex = 25;
            this.label8.Text = "PA Volts:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 421);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 20);
            this.label9.TabIndex = 26;
            this.label9.Text = "PA Temp:";
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemp.Location = new System.Drawing.Point(85, 421);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(20, 20);
            this.lblTemp.TabIndex = 27;
            this.lblTemp.Text = "F";
            this.lblTemp.Click += new System.EventHandler(this.lblTemp_Click);
            // 
            // lblDebug
            // 
            this.lblDebug.AutoSize = true;
            this.lblDebug.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebug.Location = new System.Drawing.Point(896, 432);
            this.lblDebug.Name = "lblDebug";
            this.lblDebug.Size = new System.Drawing.Size(29, 20);
            this.lblDebug.TabIndex = 28;
            this.lblDebug.Text = "     ";
            this.lblDebug.Click += new System.EventHandler(this.lblDebug_Click);
            this.lblDebug.MouseEnter += new System.EventHandler(this.lblDebug_MouseEnter);
            this.lblDebug.MouseLeave += new System.EventHandler(this.lblDebug_MouseLeave);
            // 
            // lstStations
            // 
            this.lstStations.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstStations.FormattingEnabled = true;
            this.lstStations.ItemHeight = 20;
            this.lstStations.Location = new System.Drawing.Point(176, 345);
            this.lstStations.Name = "lstStations";
            this.lstStations.Size = new System.Drawing.Size(305, 44);
            this.lstStations.TabIndex = 35;
            this.lstStations.DoubleClick += new System.EventHandler(this.lstStations_DoubleClick);
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 200;
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 200;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 40;
            this.toolTip1.ShowAlways = true;
            this.toolTip1.Tag = "";
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Freq";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.radioInfoToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(925, 24);
            this.menuStrip1.TabIndex = 36;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.showDebugScreenToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outOfBandIndicatorToolStripMenuItem,
            this.speakFrequencyToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // outOfBandIndicatorToolStripMenuItem
            // 
            this.outOfBandIndicatorToolStripMenuItem.Name = "outOfBandIndicatorToolStripMenuItem";
            this.outOfBandIndicatorToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.outOfBandIndicatorToolStripMenuItem.Text = "Out Of Band Indicator";
            this.outOfBandIndicatorToolStripMenuItem.Click += new System.EventHandler(this.outOfBandIndicatorToolStripMenuItem_Click);
            // 
            // showDebugScreenToolStripMenuItem
            // 
            this.showDebugScreenToolStripMenuItem.Name = "showDebugScreenToolStripMenuItem";
            this.showDebugScreenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.showDebugScreenToolStripMenuItem.Text = "Show Debug Screen";
            this.showDebugScreenToolStripMenuItem.Click += new System.EventHandler(this.showDebugScreenToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // radioInfoToolStripMenuItem
            // 
            this.radioInfoToolStripMenuItem.Name = "radioInfoToolStripMenuItem";
            this.radioInfoToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.radioInfoToolStripMenuItem.Text = "Radio Info";
            this.radioInfoToolStripMenuItem.Click += new System.EventHandler(this.radioInfoToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // btnFreq0Up
            // 
            this.btnFreq0Up.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreq0Up.Location = new System.Drawing.Point(366, 50);
            this.btnFreq0Up.Name = "btnFreq0Up";
            this.btnFreq0Up.Size = new System.Drawing.Size(37, 24);
            this.btnFreq0Up.TabIndex = 38;
            this.btnFreq0Up.Text = "UP";
            this.btnFreq0Up.UseVisualStyleBackColor = true;
            this.btnFreq0Up.Click += new System.EventHandler(this.btnFreq0Up_Click);
            // 
            // btnFreq0Dn
            // 
            this.btnFreq0Dn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreq0Dn.Location = new System.Drawing.Point(366, 71);
            this.btnFreq0Dn.Name = "btnFreq0Dn";
            this.btnFreq0Dn.Size = new System.Drawing.Size(37, 24);
            this.btnFreq0Dn.TabIndex = 39;
            this.btnFreq0Dn.Text = "DN";
            this.btnFreq0Dn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFreq0Dn.UseVisualStyleBackColor = true;
            this.btnFreq0Dn.Click += new System.EventHandler(this.btnFreq0Dn_Click);
            // 
            // btnFreq1Dn
            // 
            this.btnFreq1Dn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreq1Dn.Location = new System.Drawing.Point(875, 71);
            this.btnFreq1Dn.Name = "btnFreq1Dn";
            this.btnFreq1Dn.Size = new System.Drawing.Size(37, 24);
            this.btnFreq1Dn.TabIndex = 41;
            this.btnFreq1Dn.Text = "DN";
            this.btnFreq1Dn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFreq1Dn.UseVisualStyleBackColor = true;
            this.btnFreq1Dn.Click += new System.EventHandler(this.btnFreq1Dn_Click);
            // 
            // btnFreq1Up
            // 
            this.btnFreq1Up.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreq1Up.Location = new System.Drawing.Point(875, 50);
            this.btnFreq1Up.Name = "btnFreq1Up";
            this.btnFreq1Up.Size = new System.Drawing.Size(37, 24);
            this.btnFreq1Up.TabIndex = 40;
            this.btnFreq1Up.Text = "UP";
            this.btnFreq1Up.UseVisualStyleBackColor = true;
            this.btnFreq1Up.Click += new System.EventHandler(this.btnFreq1Up_Click);
            // 
            // cmbMode0
            // 
            this.cmbMode0.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMode0.FormattingEnabled = true;
            this.cmbMode0.Location = new System.Drawing.Point(8, 94);
            this.cmbMode0.Name = "cmbMode0";
            this.cmbMode0.Size = new System.Drawing.Size(92, 32);
            this.cmbMode0.TabIndex = 46;
            this.cmbMode0.SelectedIndexChanged += new System.EventHandler(this.cmbMode0_SelectedIndexChanged);
            // 
            // cmbMode1
            // 
            this.cmbMode1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMode1.FormattingEnabled = true;
            this.cmbMode1.Location = new System.Drawing.Point(525, 94);
            this.cmbMode1.Name = "cmbMode1";
            this.cmbMode1.Size = new System.Drawing.Size(92, 32);
            this.cmbMode1.TabIndex = 47;
            this.cmbMode1.SelectedIndexChanged += new System.EventHandler(this.cmbMode1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(172, 401);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 49;
            this.label1.Text = "RF Power:";
            // 
            // lblRFPower
            // 
            this.lblRFPower.AutoSize = true;
            this.lblRFPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRFPower.Location = new System.Drawing.Point(275, 398);
            this.lblRFPower.Name = "lblRFPower";
            this.lblRFPower.Size = new System.Drawing.Size(25, 20);
            this.lblRFPower.TabIndex = 48;
            this.lblRFPower.Text = "W";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(172, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 51;
            this.label2.Text = "Tune Power:";
            // 
            // lblTunePower
            // 
            this.lblTunePower.AutoSize = true;
            this.lblTunePower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTunePower.Location = new System.Drawing.Point(275, 421);
            this.lblTunePower.Name = "lblTunePower";
            this.lblTunePower.Size = new System.Drawing.Size(25, 20);
            this.lblTunePower.TabIndex = 50;
            this.lblTunePower.Text = "W";
            // 
            // txtCWSpeed
            // 
            this.txtCWSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCWSpeed.Location = new System.Drawing.Point(423, 398);
            this.txtCWSpeed.Name = "txtCWSpeed";
            this.txtCWSpeed.Size = new System.Drawing.Size(75, 26);
            this.txtCWSpeed.TabIndex = 52;
            this.txtCWSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCWSpeed_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(327, 401);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 20);
            this.label3.TabIndex = 53;
            this.label3.Text = "CW Speed:";
            // 
            // trkVol0
            // 
            this.trkVol0.Location = new System.Drawing.Point(106, 101);
            this.trkVol0.Maximum = 100;
            this.trkVol0.Name = "trkVol0";
            this.trkVol0.Size = new System.Drawing.Size(263, 45);
            this.trkVol0.TabIndex = 54;
            this.trkVol0.TickFrequency = 5;
            this.trkVol0.Scroll += new System.EventHandler(this.trkVol0_Scroll);
            // 
            // trkVol1
            // 
            this.trkVol1.Location = new System.Drawing.Point(623, 101);
            this.trkVol1.Maximum = 100;
            this.trkVol1.Name = "trkVol1";
            this.trkVol1.Size = new System.Drawing.Size(256, 45);
            this.trkVol1.TabIndex = 55;
            this.trkVol1.TickFrequency = 5;
            this.trkVol1.Scroll += new System.EventHandler(this.trkVol1_Scroll);
            // 
            // picVol0
            // 
            this.picVol0.BackColor = System.Drawing.SystemColors.Control;
            this.picVol0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picVol0.BackgroundImage")));
            this.picVol0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picVol0.InitialImage = ((System.Drawing.Image)(resources.GetObject("picVol0.InitialImage")));
            this.picVol0.Location = new System.Drawing.Point(366, 94);
            this.picVol0.Name = "picVol0";
            this.picVol0.Size = new System.Drawing.Size(37, 32);
            this.picVol0.TabIndex = 56;
            this.picVol0.TabStop = false;
            // 
            // picVol1
            // 
            this.picVol1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picVol1.BackgroundImage")));
            this.picVol1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picVol1.InitialImage = ((System.Drawing.Image)(resources.GetObject("picVol1.InitialImage")));
            this.picVol1.Location = new System.Drawing.Point(875, 94);
            this.picVol1.Name = "picVol1";
            this.picVol1.Size = new System.Drawing.Size(34, 32);
            this.picVol1.TabIndex = 57;
            this.picVol1.TabStop = false;
            // 
            // speakFrequencyToolStripMenuItem
            // 
            this.speakFrequencyToolStripMenuItem.Name = "speakFrequencyToolStripMenuItem";
            this.speakFrequencyToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.speakFrequencyToolStripMenuItem.Text = "Speak Frequency";
            this.speakFrequencyToolStripMenuItem.Click += new System.EventHandler(this.speakFrequencyToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 450);
            this.Controls.Add(this.picVol1);
            this.Controls.Add(this.picVol0);
            this.Controls.Add(this.trkVol1);
            this.Controls.Add(this.trkVol0);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCWSpeed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTunePower);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRFPower);
            this.Controls.Add(this.cmbMode1);
            this.Controls.Add(this.cmbMode0);
            this.Controls.Add(this.btnFreq1Dn);
            this.Controls.Add(this.btnFreq1Up);
            this.Controls.Add(this.btnFreq0Dn);
            this.Controls.Add(this.btnFreq0Up);
            this.Controls.Add(this.lstStations);
            this.Controls.Add(this.lblDebug);
            this.Controls.Add(this.lblTemp);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblVolts);
            this.Controls.Add(this.btnBtoA);
            this.Controls.Add(this.btnAtoB);
            this.Controls.Add(this.lblSlice1);
            this.Controls.Add(this.lblSlice0);
            this.Controls.Add(this.btnMute1);
            this.Controls.Add(this.txtFreq1);
            this.Controls.Add(this.btnMute0);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtFreq0);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "FlexRadio";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkVol0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkVol1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVol0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVol1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnMute0;
        private System.Windows.Forms.Button btnMute1;
        private System.Windows.Forms.TextBox txtFreq1;
        private System.Windows.Forms.Label lblSlice0;
        private System.Windows.Forms.Label lblSlice1;
        private System.Windows.Forms.Button btnAtoB;
        private System.Windows.Forms.Button btnBtoA;
        private System.Windows.Forms.Label lblVolts;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTemp;
        public System.Windows.Forms.TextBox txtFreq0;
        private System.Windows.Forms.Label lblDebug;
        private System.Windows.Forms.ListBox lstStations;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radioInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button btnFreq0Up;
        private System.Windows.Forms.Button btnFreq0Dn;
        private System.Windows.Forms.Button btnFreq1Dn;
        private System.Windows.Forms.Button btnFreq1Up;
        private System.Windows.Forms.ToolStripMenuItem showDebugScreenToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmbMode0;
        private System.Windows.Forms.ComboBox cmbMode1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRFPower;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTunePower;
        private System.Windows.Forms.TextBox txtCWSpeed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trkVol0;
        private System.Windows.Forms.TrackBar trkVol1;
        private System.Windows.Forms.PictureBox picVol0;
        private System.Windows.Forms.PictureBox picVol1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outOfBandIndicatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem speakFrequencyToolStripMenuItem;
    }
}