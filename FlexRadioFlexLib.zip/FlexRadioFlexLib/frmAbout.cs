﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace FlexRadioFlexLib
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            LinkLabel.Link link = new LinkLabel.Link();
            link.LinkData = "https://www.qrz.com/db/kd0rc";
            linkLabel1.Links.Add(link);
        }

        private void lblAbout_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmAbout_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(e.Link.LinkData as string);
        }

        private void frmAbout_FormClosing(object sender, FormClosingEventArgs e)
        {
            linkLabel1.Links.Clear();   // needed or next time the form is opened, it causes an argument exception
        }
    }
}
